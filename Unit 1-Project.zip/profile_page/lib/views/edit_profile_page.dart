import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

//EditProfilePage allows user to update profile page
class EditProfilePage extends StatefulWidget {
  final File? image;
  final String name;
  final String surname;
  final String phone;
  final String email;
  final String role;
  final String language;

  const EditProfilePage({
    super.key,
    required this.image,
    required this.name,
    required this.surname,
    required this.phone,
    required this.email,
    required this.role,
    required this.language,
  });
  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

//Controllers to control text fields
class _EditProfilePageState extends State<EditProfilePage> {
  late TextEditingController nameController;
  late TextEditingController surnameController;
  late TextEditingController phoneController;
  late TextEditingController emailController;
  late TextEditingController roleController;
  late TextEditingController languageController;

  File? _image;

  @override
  void initState() {
    super.initState();
    _image = widget.image;

    //Initialize text controllers with existing information
    nameController = TextEditingController(text: widget.name);
    surnameController = TextEditingController(text: widget.surname);
    phoneController = TextEditingController(text: widget.phone);
    emailController = TextEditingController(text: widget.email);
    roleController = TextEditingController(text: widget.role);
    languageController = TextEditingController(text: widget.language);
  }

  final ImagePicker _picker = ImagePicker();

  //Function to pick image from gallery
  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Edit Profile',
          style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            GestureDetector(
              onTap: _pickImage,
              child: CircleAvatar(
                radius: 65,
                backgroundColor: Colors.blue.shade100,
                backgroundImage: _image != null ? FileImage(_image!) : null,
                child: _image == null
                    ? const Icon(Icons.camera_alt, size: 40)
                    : null,
              ),
            ),

            const SizedBox(height: 30),

            //Form fields
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            TextField(
              controller: surnameController,
              decoration: const InputDecoration(labelText: 'Surname'),
            ),
            TextField(
              controller: phoneController,
              decoration: const InputDecoration(labelText: 'Phone'),
            ),
            TextField(
              controller: emailController,
              decoration: const InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: roleController,
              decoration: const InputDecoration(labelText: 'Role'),
            ),
            TextField(
              controller: languageController,
              decoration: const InputDecoration(
                labelText: 'Programming Language',
              ),
            ),

            const SizedBox(height: 20),

            //Save button
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                minimumSize: Size(double.infinity, 45),
              ),
              onPressed: () {
                Navigator.pop(context, {
                  'image': _image,
                  'name': nameController.text.trim(),
                  'surname': surnameController.text.trim(),
                  'phone': phoneController.text.trim(),
                  'email': emailController.text.trim(),
                  'role': roleController.text.trim(),
                  'language': languageController.text.trim(),
                });
              },
              child: Text(
                'Save Changes',
                style: TextStyle(color: Colors.blue, fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
