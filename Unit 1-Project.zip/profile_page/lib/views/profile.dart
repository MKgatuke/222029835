import 'dart:io';

class Profile {
  final File? image;
  final String name;
  final String surname;
  final String phone;
  final String email;
  final String role;
  final String language;

  const Profile({
    required this.image,
    required this.name,
    required this.surname,
    required this.phone,
    required this.email,
    required this.role,
    required this.language,
  });
}
