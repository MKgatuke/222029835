import 'package:flutter/material.dart';
import 'dart:io';
import 'edit_profile_page.dart';
import 'package:image_picker/image_picker.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  File? _image;

  String name = 'Michell';
  String surname = 'Kgatuke';
  String role = 'IT Student';
  String email = '222029835@stud.cut.ac.za';
  String phoneNumber = '0723075493';
  String programmingLanguage = 'Flutter';

  void updateProfile(
    File? image,
    String newName,
    String newSurname,
    String newPhone,
    String newEmail,
    String newRole,
    String newLanguage,
  ) {
    setState(() {
      _image = image;
      name = newName;
      surname = newSurname;
      phoneNumber = newPhone;
      email = newEmail;
      role = newRole;
      programmingLanguage = newLanguage;
    });
  }

  final ImagePicker _picker = ImagePicker();

  //Function to pick a profile image from gallery
  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile Page', style: TextStyle(color: Colors.blue)),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          //Profile image
          GestureDetector(
            onTap: _pickImage,
            child: CircleAvatar(
              key: ValueKey(_image?.path ?? 'no image'),
              radius: 50,
              backgroundImage: _image != null ? FileImage(_image!) : null,
              child: _image == null
                  ? const Icon(Icons.camera_alt, size: 50)
                  : null,
            ),
          ),

          SizedBox(height: 15),

          Text(
            'Name: $name',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
          ),

          SizedBox(height: 15),

          Text(
            'Surname: $surname',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
          ),

          SizedBox(height: 15),

          Text(
            'Role: $role',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
          ),

          SizedBox(height: 15),

          Text(
            'Email: $email',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
          ),

          SizedBox(height: 15),

          Text(
            'Phone Number: $phoneNumber',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
          ),

          SizedBox(height: 15),

          Text(
            'Programming Language: $programmingLanguage',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
          ),

          SizedBox(height: 15),

          //Edit button
          ElevatedButton(
            child: const Text('Edit', style: TextStyle(color: Colors.blue)),
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => EditProfilePage(
                    image: _image,
                    name: name,
                    surname: surname,
                    role: role,
                    email: email,
                    phone: phoneNumber,
                    language: programmingLanguage,
                  ),
                ),
              );

              if (result != null) {
                updateProfile(
                  result['image'],
                  result['name'],
                  result['surname'],
                  result['phone'],
                  result['email'],
                  result['role'],
                  result['language'],
                );
              }
            },
          ),
        ],
      ),
    );
  }
}
